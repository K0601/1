package com.app.timetable;
//教科入力アクテビティ
import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class Activity2_2 extends AppCompatActivity {

    private String subject;
    private String room;
    private String teacher;
    private String credit;
    private String text;
    int[] ColorNumber = new int[]{R.drawable.background3, R.drawable.background4, R.drawable.background5, R.drawable.background6, R.drawable.background7, R.drawable.background8, R.drawable.background9,
            R.drawable.background10, R.drawable.background11, R.drawable.background12, R.drawable.background13,R.drawable.background14,R.drawable.background, R.drawable.background2};
    //int[] ColorNumber = new int[]{Color.CYAN, Color.GREEN, Color.MAGENTA, Color.RED, Color.YELLOW, Color.LTGRAY, Color.GRAY, Color.WHITE,Color.BLUE};
    EditText[] editText = new EditText[5];
    int[] id = new int[]{R.id.editText0, R.id.editText1, R.id.editText2, R.id.editText3, R.id.editText4};
    int cNo;
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2_2);

        for (int i = 0; i < 5; i++)
            editText[i] = findViewById(id[i]);

        Intent i = getIntent();
        InputData sendData = (InputData) i.getSerializableExtra("key");

        subject = sendData.getKyouka();
        room = sendData.getKyoushitsu();
        teacher = sendData.getKyouin();
        credit = sendData.getTani();
        text = sendData.getKyouzai();
        cNo = sendData.getColor();
        //データをセット
        editText[0].setText(subject);
        editText[1].setText(room);
        editText[2].setText(teacher);
        editText[3].setText(credit);
        editText[4].setText(text);
        buttonColor(cNo);
        ad();
    }

    private void ad(){
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        AdSize adSize = new AdSize(300, 50);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
    }


    public void onClickSave(View view) {

        //入力データ読み取り
        String subject = editText[0].getText().toString();
        String room = editText[1].getText().toString();
        String teacher = editText[2].getText().toString();
        String credit = editText[3].getText().toString();
        String text = editText[4].getText().toString();

        InputData inputData = new InputData();

        inputData.setKyouka(subject);
        inputData.setKyoushitsu(room);
        inputData.setKyouin(teacher);
        inputData.setTani(credit);
        inputData.setKyouzai(text);
        inputData.setColor(cNo);

        Intent intent = new Intent(Activity2_2.this, MainActivity.class);
        intent.putExtra("data", inputData);
        setResult(RESULT_OK, intent);
        Log.v("cNo", "cNoは" + cNo);
        finish();
    }
    //キャンセルボタンクリック時
    public void onClickCancel(View view) {
        setResult(RESULT_CANCELED);
        finish();
    }

    //色選択アクテビティを起動
    public void onClick_color(View view) {
        Intent intent = new Intent(this, Activity2_1.class);
        startActivityForResult(intent, 999);
    }
    //色選択アクテビティ結果
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == 999 && resultCode == RESULT_OK) {
            cNo = intent.getIntExtra("color", cNo);
            buttonColor(cNo);
        }
    }
    public void buttonColor(int cNo){
        Button button = findViewById(R.id.color_button);
        //button.setBackgroundColor(ColorNumber[cNo]);
        button.setBackgroundResource(ColorNumber[cNo]);
    }
}
