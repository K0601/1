package com.app.timetable;

import java.io.Serializable;

public class InputData implements Serializable {
    private String kyouka;
    private String kyoushitsu;
    private String kyouin;
    private String tani;
    private String kyouzai;
    private int color;

    public InputData() {
    }

    InputData(String data1, String data2, String data3, String data4, String data5, int data6) {
        this.kyouka = data1;
        this.kyoushitsu = data2;
        this.kyouin = data3;
        this.tani = data4;
        this.kyouzai = data5;
        this.color = data6;
    }


    public String getKyouka() {
        return kyouka;
    }

    public void setKyouka(String kyouka) {
        this.kyouka = kyouka;
    }

    public String getKyoushitsu() {
        return kyoushitsu;
    }

    public void setKyoushitsu(String kyoushitsu) {
        this.kyoushitsu = kyoushitsu;
    }

    public String getKyouin() {
        return kyouin;
    }

    public void setKyouin(String kyouin) {
        this.kyouin = kyouin;
    }

    public String getTani() {
        return tani;
    }

    public void setTani(String tani) {
        this.tani = tani;
    }

    public String getKyouzai() {
        return kyouzai;
    }

    public void setKyouzai(String kyouzai) {
        this.kyouzai = kyouzai;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
