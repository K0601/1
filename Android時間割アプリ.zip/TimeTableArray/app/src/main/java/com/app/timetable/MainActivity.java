package com.app.timetable;

//キャンセルボタン押下時の広告

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import static java.lang.String.valueOf;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static int i = 10;//縦
    public static int j = 8;//横
    int k = 5;//入力項目数
    int l = k + 1;//key数
    int t = 2;//時間の数
    int textSize = 10;
    TableLayout tableLayout;
    FrameLayout frameLayout;
    private TextView[][] textView;// = new TextView[i][j];
    TextView[][][] time;// = new TextView[i][j][t];
    private TextView copy;
    Boolean c = false;

    int[] ColorNumber = new int[]{R.drawable.background3, R.drawable.background4, R.drawable.background5, R.drawable.background6, R.drawable.background7, R.drawable.background8, R.drawable.background9,
            R.drawable.background10, R.drawable.background11, R.drawable.background12, R.drawable.background13,R.drawable.background14,R.drawable.background, R.drawable.background2};
    static int reqCode;
    private int color;
    private int clickMode = 0;

    //string[0] = 教科 string[1] = 教室 string[2] = 教員 string[3] = 単位 string [4] = 教材
    private String[] string1 = new String[k];
    String[][] timer = new String[i][t];

    //string2[][][0] = 教科 string2[][][1] = 教室 string2[][][2] = 教員 string2[][][3] = 単位 string2[][][4] = 教材
    String[][][] string2 = new String[i][j][k];
    int[][] BGColor = new int[i][j];
    private int[] isDayOfWeek = {R.string.Mon, R.string.Tue, R.string.Wed, R.string.Thu, R.string.Fri, R.string.Sat, R.string.Sun};
    private int[] weekId = {R.id.checkBox0, R.id.checkBox1, R.id.checkBox2, R.id.checkBox3, R.id.checkBox4, R.id.checkBox5, R.id.checkBox6};
    //private String[][] time = new String[i][t];

    private final int match_parent = ViewGroup.LayoutParams.MATCH_PARENT;
    private AdView mAdView;

    EditText ediTime;
    private Boolean toggle_switch = false;
    private Boolean[] weekDays = new Boolean[]{true, true, true,true, true,true, true};
    private CheckBox[] checkBoxes = new CheckBox[7];



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //tableLayout = initTableLayout();
        //setContentView(tableLayout);
        setContentView(R.layout.activity_main);
        load_i_j();
        textView = new TextView[i][j];
        time = new TextView[i][j][t];
        initTableLayout();
        setData();
        ad();

    }

    private void ad(){
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
    }

    private void setData(){
        for(int a = 0; a < i; a++){
            for(int b = 0; b < j; b++){
                if(b != 0 && a != 0) {
                    //データ呼び出し
                    Data saveData = loadData(a, b);
                    for (int c = 0; c < k; c++) {
                        string1[c] = saveData.str[c];
                        if (string1[c] == null)string1[c] = "";
                    }
                    color = saveData.cr;
                    if (string1[0] == "" && string1[1] == "")color = 12;
                    setColor(a,b,color);
                }
            }
        }
    }

    //TableLayoutの生成
    private void initTableLayout() {
         //tableLayout = new TableLayout(this);
        tableLayout = findViewById(R.id.tableLayout);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(match_parent, match_parent);
        tableLayout.setLayoutParams(layoutParams);
        float dp = getResources().getDisplayMetrics().density;
        int padding_bottom = (int)(50*dp);
        tableLayout.setPadding(0, 0, 0 , padding_bottom);

        // ---------------- TableRowの生成 ---------------- //
        for (int a = 0; a < i; a++) {
            TableRow tableRow = new TableRow(this);
            tableRow.setGravity(Gravity.CENTER);
            if (a == 0) {
                TableLayout.LayoutParams params = new TableLayout.LayoutParams(0, 0);
                tableRow.setLayoutParams(params);
            }
            // 曜日以外の行はweightを1に設定
            else {
                TableLayout.LayoutParams params = new TableLayout.LayoutParams(0, 0, 1f);
                tableRow.setLayoutParams(params);
            }
            tableLayout.addView(tableRow);

            // ---------------- FrameLayoutの生成 ---------------- //
            for (int b = 0; b < j; b++) {
                //*tableRow.addView(createTextView(b, a));
                tableRow.addView(createFrameLayout(a, b));
            }
        }
        //return tableLayout;
    }

    //FrameLayout の生成
    private FrameLayout createFrameLayout(int a, int b){
        frameLayout = new FrameLayout(this);
        TableRow.LayoutParams params;
        if (b == 0) {
            params = new TableRow.LayoutParams(0, match_parent, 0.4f);
        }else{
            params = new TableRow.LayoutParams(0, match_parent, 1f);
        }
        frameLayout.setLayoutParams(params);
        if (b == 0){
            frameLayout.addView(createTextView(a, b),0);
            frameLayout.addView(createTimeText(0, a, b),1);
            frameLayout.addView(createTimeText(1, a, b),2);
        } else{
            frameLayout.addView(createTextView(a, b), 0);
            frameLayout.addView(createTextView(a, b), 1);
            if (!weekDays[b-1])frameLayout.setVisibility(View.GONE);
        }

        return frameLayout;
    }

    //TextViewの生成
    private TextView createTextView(int a, int b/*横*/) {
        Log.v("textView, i", String.valueOf(i));
        textView[a][b] = new TextView(this);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(match_parent,match_parent,Gravity.CENTER_HORIZONTAL);
        textView[a][b].setLayoutParams(params);

        ViewGroup.MarginLayoutParams margin = (ViewGroup.MarginLayoutParams)params;
        margin.setMargins(4, 4, 4, 4);
        textView[a][b].setLayoutParams(margin);
        if (b == 0 && a != 0){
            textView[a][b].setText(String.valueOf(a));
        } else if (b != 0 && a == 0){
            textView[a][b].setText(isDayOfWeek[b - 1]);
        }

        // 文字入力でレイアウトが変わらないように高さを固定
        if (a != 0) {
            textView[a][b].setHeight(0);
            textView[a][b].setOnClickListener(this);
        }
        // dp単位を取得
        float dp = getResources().getDisplayMetrics().density;
        // マージン 10dp に設定

        int padding = (int) (5 * dp);
        textView[a][b].setGravity(Gravity.CENTER);
        textView[a][b].setPadding(padding, padding, padding, padding);
        textView[a][b].setTextSize(textSize);
        if (a == 0 || b == 0) textView[a][b].setBackgroundResource(R.drawable.background2);
        else textView[a][b].setBackgroundResource(R.drawable.background);

        return textView[a][b];
    }

    //時間部分のTextViewの設定
    private TextView createTimeText(int m, int a, int b) {
        FrameLayout.LayoutParams params1 = new FrameLayout.LayoutParams(match_parent,match_parent, Gravity.CENTER_HORIZONTAL);
        time[a][b][m] = new TextView(this);
        time[a][b][m].setTextSize(textSize);
        //テキストの設定
        if (a != 0){
            loadTime(a, m);
            if (m == 0){
                time[a][b][m].setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            }else{
                time[a][b][m].setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            }
        }
        time[a][b][m].setLayoutParams(params1);
        Log.v("time", a +"," + b + ","+ m +": " + time[a][b][m].getText().toString() );
        if(!toggle_switch && b == 0){
            time[a][b][m].setVisibility(View.INVISIBLE);
        }
        return time[a][b][m];
    }

//クリック処理Activity2_2・TimeSetActivityを起動
    public void onClick(View v){
        if(clickMode == 0) {
            if (v instanceof CheckBox) {
                //チェックボックスの場合
                for (int a = 0; a < 7; a++) {
                    if (v == checkBoxes[a]) {
                        boolean check = checkBoxes[a].isChecked();
                        weekDays[a] = check;
                        Log.v("checkbox", String.valueOf(a) + ":" + String.valueOf(weekDays[a]));
                    }

                }
            } else {
                TimeData timeData = new TimeData(i, t, toggle_switch);
                for (int n = 1; n < i; n++) {
                    for (int m = 1; m < j; m++) {
                        //時間割入力部分
                        if (v == textView[n][m]) {//Activity2_2を起動

                            Intent intent = new Intent(this, Activity2_2.class);
                            reqCode = 100 + 10 * n + m;

                            Data saveData = loadData(n, m);
                            for (int i = 0; i < k; i++) {
                                string1[i] = saveData.str[i];
                            }
                            color = saveData.cr;

                            InputData sendData = new InputData();
                            sendData.setKyouka(string1[0]);
                            sendData.setKyoushitsu(string1[1]);
                            sendData.setKyouin(string1[2]);
                            sendData.setTani(string1[3]);
                            sendData.setKyouzai(string1[4]);
                            sendData.setColor(color);
                            intent.putExtra("key", sendData);

                            startActivityForResult(intent, reqCode);
                        } else if (v == textView[n][0]) {//TimeSetActivity を起動
                            Intent intent = new Intent(this, TimeSetActivity.class);
                            reqCode = 50;
                            for (int a = 0; a < i - 1; a++) {
                                for (int b = 0; b < t; b++) {
                                    timeData.setTime(timer[a][b], a, b);
                                }
                            }
                            intent.putExtra("number", timeData);
                            startActivityForResult(intent, reqCode);
                            break;
                        }
                    }
                }
            }
        }else if(clickMode == 1){
            for(int a = 1; a < i; a++){
                for (int b = 1; b < j; b++){
                    if (v == textView[a][b]){
                        if (!c){
                            copy = textView[a][b];
                            c = true;
                        } else {
                            textView[a][b] = copy;
                            c = false;
                            break;
                        }
                    }
                }
            }
            /*initTableLayout();
            setData();
            ad();*/
        }else{

        }
    }

    //画面遷移から戻った処理
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            int p;
            int q;
            p = (requestCode - 100) / 10;//縦
            q = requestCode - 100 - 10*p;//横

            if (q != 0){
                if(requestCode == reqCode) {
                    //Activity2_2から戻った処理
                    InputData inputData = (InputData) data.getSerializableExtra("data");
                    string1[0] = inputData.getKyouka();
                    string1[1] = inputData.getKyoushitsu();
                    string1[2] = inputData.getKyouin();
                    string1[3] = inputData.getTani();
                    string1[4] = inputData.getKyouzai();
                    color = inputData.getColor();
                    saveData(p, q, string1, color, i, j);
                    if (string1[0] == "" && string1[1] == "")color = 12;
                    setColor(p,q,color);
                }else{
                    Data saveData = loadData(p, q);
                    for (int i = 0; i < k; i++) {
                        string1[i] = saveData.str[i];
                    }
                    color = saveData.cr;
                    setColor(p,q,color);
                }
            }else if (requestCode == 50){
                //TimeSetActivity から戻った処理
                TimeData timeData = (TimeData)data.getSerializableExtra("time");
                toggle_switch = timeData.toggle_switch;
                for (int a = 0; a < i-1 ; a++){
                    for (int b = 0; b < t; b++){
                        timer[a][b] = timeData.getTime(a, b);
                        Log.v("time_Main", timer[a][b]);
                        setTime(timer[a][b], a, b);
                        saveTime(timer[a][b], a, b, toggle_switch);//a= 0 ～ i-1
                    }
                }
            }

        }
    }

    //
    public void setTime(String string, int a, int b){
        time[a + 1][0][b].setText(string);
        if (!toggle_switch) time[a + 1][0][b].setVisibility(View.INVISIBLE);
        else time[a + 1][0][b].setVisibility(View.VISIBLE);

    }

    //i, j 曜日のBooleanの保存
    public void save_i_j(int vertical, int horizontal, Boolean[] ON_OFF){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String[] key = new String[9];
        //i = 1000　j = 2000　曜日 月～日 3000~9000
        for (int a = 0; a < 9; a++)key[a] = String.valueOf(1000 * (a+1));
         sp.edit().putInt(key[7], vertical).apply();
        sp.edit().putInt(key[8], horizontal).apply();
        for (int a = 0; a < 7; a++) sp.edit().putBoolean(key[a], ON_OFF[a]).apply();
    }

    //i, j 曜日のBooleanの呼び出し
    public void load_i_j(){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String[] key = new String[9];
        for (int a = 0; a < 9; a++)key[a] = String.valueOf(1000 * (a+1));
        for (int a = 0; a < 7; a++) weekDays[a] = sp.getBoolean(key[a], true);
        i = sp.getInt(key[7], 9);
        j = sp.getInt(key[8], 7);
    }

    public void saveTime(String str, int a, int b, Boolean toggle) {
        String key = valueOf(10 * a + b);
        String toggle_key = "toggle";
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        Log.v("timeData", str+ valueOf(a) + valueOf(b));
        sp.edit().putString(key, str).apply();
        sp.edit().putBoolean(toggle_key, toggle).apply();
    }

    public void loadTime(int a, int b){
        a = a-1;
        String key = valueOf(10 * a + b);
        String toggle_key = "toggle";
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        timer[a][b] = sp.getString(key, ":");
        toggle_switch = sp.getBoolean(toggle_key, false);
        setTime(timer[a][b], a, b);
    }


    //背景色設定関数
    public void setColor(int n, int m, int color){
        textView[n][m].setText(string1[0] + "\n"+ "\n" + string1[1]);
        textView[n][m].setTextSize(textSize);
        //GradientDrawable background = (GradientDrawable) textView[n][m].getBackground();
        //background.setColor(ColorNumber[color]);
        textView[n][m].setBackgroundResource(ColorNumber[color]);
    }

    //データ保存関数
    public void saveData(int p, int q, String[] str, int color, int vertical, int horizontal){
        String[] key = new String[l];
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);

        for (int i = 0; i < k; i ++)string2[p][q][i] = str[i];
        BGColor[p][q] = color;
        for (int a = 0; a < l; a++)key[a] = valueOf(p*100+q*10+a);
        //データ保存キーの設定
        for (int a = 0; a < k; a ++)sp.edit().putString(key[a], string2[p][q][a]).apply();
        sp.edit().putInt(key[5], BGColor[p][q]).apply();
    }


    class Data{
        String[] str = new String[k];
        int cr;
    }

    //データ呼び出し関数
    public Data loadData(int p, int q){
        String[] key = new String[l];
        Data saveData = new Data();
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        for (int a = 0; a < l; a++)key[a] = valueOf(p*100+q*10+a);
        for (int a = 0; a < k; a++)saveData.str[a] = sp.getString(key[a], null);
        saveData.cr = sp.getInt(key[5], 0);
        return saveData;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //メニュー選択
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
            switch (itemId){
                //言語の変更選択時
                case R.id.menu_edit:
                    edit();
                    break;

                case R.id.menu_setting:
                    setContentView(R.layout.layout_setting);
                    settingMethod();
                    break;

                case R.id.menu_language:
                    languageAlert();
                    break;
                    //データの削除選択時
                case R.id.menu_delete:
                    showAlert();
                    break;

            }
        return true;
    }

    private void edit(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("編集");
        builder.setMessage("編集内容");
        builder.setPositiveButton("コピー", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                clickMode = 1;
            }
        });

        builder.setNegativeButton("削除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                clickMode = 2;
            }
        });

        builder.setNeutralButton("キャンセル", null);
        builder.show();
    }

    //設定関係
    //-------------------layout_setting-------------------//
    private void settingMethod(){
        ediTime = findViewById(R.id.edit_time);
        ediTime.setText(valueOf(i-1));
        setCheckBoxes();
        ad();
    }

    private void setCheckBoxes(){
        for (int a = 0; a < 7; a++){
            checkBoxes[a] = findViewById(weekId[a]);
            checkBoxes[a].setOnClickListener(this);
            checkBoxes[a].setChecked(weekDays[a]);
        }
    }

    //設定キャンセルボタン
    public void onClickCancelButton(View view) {
        setContentView(R.layout.activity_main);
        initTableLayout();
        setData();
        ad();
    }

    //設定の保存ボタン
    public void onClickSaveButton(View view) {
        if (!ediTime.getText().toString().equals("")) i = Integer.parseInt(ediTime.getText().toString()) + 1;
        save_i_j(i, j, weekDays);
        setContentView(R.layout.activity_main);
        Log.v("setting, i", String.valueOf(i));
        initTableLayout();
        setData();
        ad();

    }

    //言語変更アラート
    private  void languageAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final String[] items = {"English", "日本語", "简体(中文)"};
        int defaultItem = 0; // デフォルトでチェックされているアイテム
        final List<Integer> checkedItems = new ArrayList<>();
        checkedItems.add(defaultItem);
        builder.setTitle(R.string.language);
        builder.setIcon(R.drawable.ic_translate_black_24dp);
        builder.setSingleChoiceItems(items, defaultItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        checkedItems.clear();
                        checkedItems.add(which);
                    }
                });
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int checkNo = checkedItems.get(0);
                        if (!checkedItems.isEmpty()) {
                            Log.d("checkedItem:", "" + checkedItems.get(0));
                        }
                        initialize(checkNo);
                    }
                });
        builder.setNegativeButton(R.string.buttonText2, null);
        builder.show();
    }

    //言語の変更内容
    private void initialize(int checkNo) {
        // 言語の切替え
        Locale locale = Locale.getDefault(); 			// アプリで使用されているロケール情報を取得
        if (checkNo == 0) {
            locale = Locale.US;
        } else if (checkNo == 1){
            locale = Locale.JAPAN;
        }else {
            locale = Locale.CHINA;
        }
        Locale.setDefault(locale); 						// 新しいロケールを設定
        Configuration config = new Configuration();
        config.locale = locale; 						// Resourcesに対するロケールを設定
        Resources resources = getBaseContext().getResources();
        resources.updateConfiguration(config, null); 	// Resourcesに対する新しいロケールを反映
        setContentView(R.layout.activity_main);
        initTableLayout();
        setData();
        ad();
}

    //データ削除選択時アラート
    public void showAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_warning_black_24dp);
        builder.setTitle(R.string.alert_title);
        builder.setMessage(R.string.alert_message);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteData();
            }
        });
        builder.setNegativeButton(R.string.buttonText2, null);
        builder.show();
    }

    //データの削除
    public void deleteData(){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        editor.apply();
        restart();
    }

    //アプリの再起動
    void restart(){
        Intent intent = getIntent();
        PendingIntent appStarter = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), appStarter);
        finish();
    }


}
