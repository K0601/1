package com.app.timetable;

import android.util.Log;

import java.io.Serializable;

public class TimeData implements Serializable {
    public int i;
    public int j;
    private String[][] str;
    public Boolean toggle_switch = false;

    public TimeData(int a, int b, Boolean toggle){
        this.i = a;
        this.j = b;
        this.toggle_switch = toggle;
        str = new String[this.i][this.j];
        Log.v("i", "i:"+ this.i);
        Log.v("j", "j:"+ this.j);
    }

    public String getTime(int m, int n){
        return str[m][n];
    }

    public void setTime(String time, int m, int n){
        this.str[m][n] = time;
        Log.v("str", "str[" + m + "][" + n + "] :" + str[m][n]);
    }
}

