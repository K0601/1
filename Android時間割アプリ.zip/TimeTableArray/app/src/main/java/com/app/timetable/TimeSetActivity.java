package com.app.timetable;

import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

/*やること
入力ありか無しかの設定
*/
public class TimeSetActivity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private int i;//時間数
    private int j = 4;//TextView数
    private int k = 2;//ボタン数&&時間数
    private TextView[][] textView;
    private EditText[][] editText;
    private Button[] button = new Button[k];
    String[][] time;
    String[][] send_time;
    String[] string;
    private AdView mAdView;
    TableLayout tableLayout;
    private int textSize = 15;
    private Boolean toggle_switch = false;
    CompoundButton toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        TimeData timeData = (TimeData) intent.getSerializableExtra("number");
        i = timeData.i - 1;

        toggle_switch = timeData.toggle_switch;

        Log.v("value_of_i", String.valueOf(i));
        setContentView(R.layout.activity_time_set);
        textView = new TextView[i][j];
        editText = new EditText[i][j];
        time = new String[i][j];
        send_time = new String[i][k];
        initLinearLayout();
        setSwitchButton();

        //initTextView();
        getData(timeData);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        AdSize adSize = new AdSize(300, 50);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });

    }

    private void getData(TimeData timeData) {
        string = new String[i];
        for (int a = 0; a < i; a++) {
            for (int b = 0; b < k; b++) {
                send_time[a][b] = timeData.getTime(a, b);
                Log.v("got_time", a + "," + b + "=" + send_time[a][b]);
            }
            string[a] = send_time[a][0] + ":" + send_time[a][1];
            time[a] = string[a].split(":", -1);
            Log.v("string", string[a]);
            for (int b = 0; b < j; b++) {
                Log.v("time_", a + "," + b + ":" + time[a][b]);
                editText[a][b].setText(time[a][b]);
            }
        }
    }

    private void setSwitchButton() {
        toggle = findViewById(R.id.toggle_switch);
        toggle.setOnCheckedChangeListener(this);
        Log.v("toggle", toggle_switch.toString());
        toggle.setChecked(toggle_switch);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        toggle_switch = isChecked;
    }

    private void initLinearLayout() {
        LinearLayout linearLayout = findViewById(R.id.linearLayout);
        RelativeLayout.LayoutParams r_params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setLayoutParams(r_params);
        //linearLayout.setOrientation(LinearLayout.VERTICAL);
        //linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.addView(initTextView());
        linearLayout.addView(buttonLayout());

    }

    private TableLayout initTextView() {
        tableLayout = new TableLayout(this);

        for (int m = 0; m < i; m++) {
            TableRow tableRow = new TableRow(this);
            tableRow.setGravity(Gravity.CENTER);
            TableLayout.LayoutParams params = new TableLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tableRow.setLayoutParams(params);
            tableLayout.addView(tableRow);

            //TextView EditView Buttonの生成
            for (int n = 0; n < j; n++) {
                tableRow.addView(createTextView(n, m));
                tableRow.addView(createEditText(n, m));
            }
        }
        return tableLayout;
    }

    //TextViewの生成
    private TextView createTextView(int n, int m) {
        textView[m][n] = new TextView(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textView[m][n].setLayoutParams(params);
        textView[m][n].setTextSize(textSize);
        if (n == 0) textView[m][n].setText(String.valueOf(m + 1));
        else if (n == 2) textView[m][n].setText("～");
        else textView[m][n].setText(":");
        return textView[m][n];
    }

    //EditTextの生成
    private EditText createEditText(int n, int m) {
        editText[m][n] = new EditText(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        editText[m][n].setLayoutParams(params);
        editText[m][n].setTextSize(textSize);
        editText[m][n].setInputType(InputType.TYPE_CLASS_DATETIME);
        InputFilter[] filter = new InputFilter[1];
        filter[0] = new InputFilter.LengthFilter(2);
        editText[m][n].setFilters(filter);
        return editText[m][n];
    }

    private LinearLayout buttonLayout() {
        LinearLayout linear_button = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linear_button.setLayoutParams(params);
        linear_button.setGravity(Gravity.CENTER_HORIZONTAL);
        for (int m = 0; m < k; m++) {
            linear_button.addView(createButton(m));
        }

        return linear_button;
    }

    //Buttonの生成
    private Button createButton(int m) {
        button[m] = new Button(this);
        if (m == 0) button[m].setText(R.string.buttonText2);
        else button[m].setText(R.string.buttonText1);
        button[m].setOnClickListener(this);

        return button[m];
    }


    @Override
    public void onClick(View v) {
        if (v == button[0]) {
            setResult(RESULT_CANCELED);
            finish();
        } else {
            Intent intent = new Intent(TimeSetActivity.this, MainActivity.class);

            for (int m = 0; m < i; m++) {
                for (int n = 0; n < j; n++) {
                    time[m][n] = editText[m][n].getText().toString();
                    int num = 0;
                    if ("".equals(time[m][n])) {
                        //time[m][n] = "00";
                    } else {
                        num = Integer.parseInt(time[m][n]);
                    }
                    if (n % 2 == 0 && num > 24) {
                        time[m][n] = "00";
                    } else if (n % 2 == 1 && num > 59) {
                        time[m][n] = "00";
                    }
                    Log.v("time", time[m][n]);
                }

                for (int n = 0; n < k; n++) {
                    if (n == 0) {
                        send_time[m][n] = time[m][0] + ":" + time[m][1];
                    } else {
                        send_time[m][n] = time[m][2] + ":" + time[m][3];
                    }
                    Log.v("send_time", send_time[m][n]);
                }
            }

            TimeData timeData = new TimeData(i, k, toggle_switch);

            for (int m = 0; m < i; m++) {
                for (int n = 0; n < k; n++) {
                    timeData.setTime(send_time[m][n], m, n);
                }
            }
            intent.putExtra("time", timeData);
            setResult(RESULT_OK, intent);
            finish();

        }
    }
}


